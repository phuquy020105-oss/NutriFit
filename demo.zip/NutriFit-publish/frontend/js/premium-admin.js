/* Premium checkout + Admin dashboard. Uses only API contracts present in this project. */
(function () {
  'use strict';

  const state = {
    plans: [],
    paymentHistory: [],
    adminUsers: [],
    adminTransactions: [],
    adminPeriod: 'day',
    loadingPlans: false,
    loadingCheckout: false
  };

  const $ = id => document.getElementById(id);
  const sessionUser = () => window.NutriFitAuth?.getSession?.()?.user || null;
  const userId = () => Number(sessionUser()?.id) || null;
  const isAdmin = () => String(sessionUser()?.role || '').toUpperCase() === 'ADMIN';

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[char]));
  }

  function formatMoney(value) {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return '—';
    return new Intl.NumberFormat('vi-VN', { maximumFractionDigits: 0 }).format(amount) + ' ₫';
  }

  function formatDate(value) {
    if (!value) return '—';
    const text = String(value).replace('T', ' ');
    const date = new Date(text.length === 10 ? `${text}T00:00:00` : text.replace(' ', 'T'));
    return Number.isNaN(date.getTime()) ? escapeHtml(value) : date.toLocaleString('vi-VN');
  }

  function statusText(status) {
    const key = String(status || 'UNKNOWN').toUpperCase();
    const map = {
      SUCCESS: ['Thành công', 'success'],
      PENDING: ['Chờ thanh toán', 'pending'],
      FAILED: ['Thất bại', 'danger'],
      CANCELLED: ['Đã hủy', 'danger'],
      REFUNDED: ['Đã hoàn tiền', 'neutral']
    };
    return map[key] || [key, 'neutral'];
  }

  function statusPill(status) {
    const item = statusText(status);
    return `<span class="nf-status nf-status-${item[1]}">${escapeHtml(item[0])}</span>`;
  }

  function setMessage(id, message, kind = 'info') {
    const element = $(id);
    if (!element) return;
    element.textContent = message || '';
    element.className = `nf-inline-status nf-inline-status-${kind}${message ? '' : ' hidden'}`;
  }

  async function syncSessionUser() {
    if (!userId()) return null;
    const result = await window.NutriFitAPI.getCurrentUser();
    if (!result.success || !result.user) return null;
    const cached = window.NutriFitAuth.getSession();
    window.NutriFitAuth.saveSession(result.user, cached?.profile || null);
    return window.NutriFitAuth.getSession()?.user || null;
  }

  function applyRoleNavigation() {
    const admin = isAdmin();
    ['nav-item-admin', 'mobile-nav-item-admin'].forEach(id => $(id)?.classList.toggle('hidden', !admin));
    $('section-admin')?.classList.toggle('hidden', !admin);
    const user = sessionUser();
    const pill = $('premium-membership-label');
    const membershipPill = $('premium-membership-pill');
    if (pill && membershipPill) {
      const premium = String(user?.subscription_status || '').toUpperCase() === 'PREMIUM';
      pill.textContent = premium ? `Premium${user?.premium_expires_at ? ` · hết hạn ${formatDate(user.premium_expires_at)}` : ''}` : 'Gói Free';
      membershipPill.classList.toggle('is-premium', premium);
    }
  }

  function renderPlans(plans) {
    const container = $('premium-plans');
    if (!container) return;
    if (!plans.length) {
      container.innerHTML = '<div class="nf-empty-state md:col-span-2"><strong>Chưa có gói dịch vụ trong database.</strong><span>Kiểm tra bảng SubscriptionPlans và chạy migration nâng cấp an toàn nếu bảng chưa có gói mặc định.</span></div>';
      return;
    }
    const active = String(sessionUser()?.subscription_status || '').toUpperCase() === 'PREMIUM';
    container.innerHTML = plans.map((plan, index) => {
      const id = Number(plan.plan_id);
      const name = escapeHtml(plan.plan_name || 'Gói Premium');
      const days = Number(plan.duration_days) || 0;
      const description = escapeHtml(plan.description || 'Mở khóa thêm các tính năng NutriFit.');
      const monthly = days > 0 ? Math.round(Number(plan.price_vnd || 0) / days * 30) : 0;
      const featured = index === 1 || days >= 365;
      return `<article class="nf-plan-card${featured ? ' nf-plan-featured' : ''}">
        <div class="nf-plan-top"><span class="nf-plan-icon" aria-hidden="true">${featured ? '♛' : '✦'}</span><span class="nf-plan-duration">${days} ngày</span></div>
        <h3>${name}</h3><p class="nf-plan-description">${description}</p>
        <div class="nf-plan-price">${formatMoney(plan.price_vnd)}</div>
        <p class="nf-plan-subprice">${monthly ? `Tương đương ${formatMoney(monthly)} / 30 ngày` : 'Giá theo cấu hình gói'}</p>
        <ul class="nf-plan-features"><li>Gợi ý thực đơn và theo dõi dinh dưỡng</li><li>Ghi nhận món ăn và lịch tập trên cùng hồ sơ</li><li>Quyền Premium có thời hạn theo gói đã mua</li></ul>
        <button type="button" class="nf-btn ${featured ? 'nf-btn-dark' : 'nf-btn-primary'} nf-plan-buy" ${!Number.isInteger(id) || id <= 0 ? 'disabled' : ''} onclick="startPremiumCheckout(${id})">${active ? 'Mua thêm thời hạn' : 'Chọn gói & thanh toán'} <span aria-hidden="true">→</span></button>
      </article>`;
    }).join('');
  }

  async function loadPremiumPage() {
    applyRoleNavigation();
    const status = $('premium-status-message');
    if (!userId()) {
      setMessage('premium-status-message', 'Vui lòng đăng nhập để tạo yêu cầu thanh toán và xem lịch sử.', 'warning');
      renderPlans(state.plans);
      return;
    }

    if (!state.loadingPlans) {
      state.loadingPlans = true;
      setMessage('premium-status-message', 'Đang tải bảng giá từ Backend…', 'info');
      try {
        await syncSessionUser();
        const result = await window.NutriFitAPI.getPaymentPlans();
        if (!result.success) {
          setMessage('premium-status-message', result.message || 'Không tải được các gói Premium.', 'error');
        } else {
          state.plans = Array.isArray(result.data) ? result.data : [];
          renderPlans(state.plans);
          setMessage('premium-status-message', state.plans.length ? `Có ${state.plans.length} gói dịch vụ đang được cung cấp.` : 'Backend chưa có gói dịch vụ đang hoạt động.', state.plans.length ? 'success' : 'warning');
        }
      } catch (error) {
        setMessage('premium-status-message', 'Không thể tải bảng giá. Vui lòng kiểm tra Backend.', 'error');
      } finally {
        state.loadingPlans = false;
      }
    } else {
      renderPlans(state.plans);
    }
    await refreshPaymentHistory();
    applyRoleNavigation();
  }

  async function startPremiumCheckout(planId) {
    if (state.loadingCheckout) return;
    const id = Number(planId);
    if (!Number.isInteger(id) || id <= 0) return;
    if (!userId()) {
      setMessage('premium-status-message', 'Phiên đăng nhập chưa sẵn sàng. Hãy đăng nhập lại trước khi mua gói.', 'warning');
      return;
    }
    const button = document.querySelector(`button[onclick="startPremiumCheckout(${id})"]`);
    state.loadingCheckout = true;
    if (button) { button.disabled = true; button.dataset.originalText = button.textContent; button.textContent = 'Đang tạo yêu cầu…'; }
    setMessage('premium-status-message', 'Đang tạo yêu cầu thanh toán…', 'info');
    try {
      await syncSessionUser();
      const result = await window.NutriFitAPI.createPaymentCheckout(id);
      if (!result.success || !result.data) {
        setMessage('premium-status-message', result.message || 'Không tạo được yêu cầu thanh toán.', 'error');
        return;
      }
      const data = result.data;
      $('payment-checkout-panel')?.classList.remove('hidden');
      $('checkout-plan-name').textContent = data.plan_name || 'Gói Premium';
      $('checkout-amount').textContent = formatMoney(data.amount_vnd);
      $('checkout-code').textContent = data.transaction_code || '';
      $('checkout-message').textContent = result.message || 'Đã tạo yêu cầu. Vui lòng thực hiện thanh toán theo thông tin trên.';
      const qr = $('checkout-qr');
      const qrFallback = $('checkout-qr-fallback');
      const qrUrl = String(data.qr_code_url || '');
      let safeQr = false;
      try { safeQr = new URL(qrUrl).hostname === 'img.vietqr.io' && new URL(qrUrl).protocol === 'https:'; } catch (_) { safeQr = false; }
      if (qr && safeQr) {
        qr.src = qrUrl;
        qr.classList.remove('hidden');
        if (qrFallback) qrFallback.classList.add('hidden');
        qr.onerror = () => { qr.classList.add('hidden'); qrFallback?.classList.remove('hidden'); if (qrFallback) qrFallback.textContent = 'Không tải được hình QR. Kiểm tra kết nối mạng hoặc dùng thông tin giao dịch để đối soát.'; };
      } else {
        qr?.classList.add('hidden');
        if (qrFallback) { qrFallback.classList.remove('hidden'); qrFallback.textContent = 'Backend không trả về URL QR hợp lệ. Không tiếp tục chuyển khoản; hãy liên hệ quản trị viên.'; }
      }
      setMessage('premium-status-message', `Đã tạo yêu cầu ${data.transaction_code || ''}. Hãy đọc kỹ thông tin trước khi chuyển khoản.`, 'success');
      $('payment-checkout-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
      await refreshPaymentHistory();
    } catch (error) {
      setMessage('premium-status-message', 'Không thể kết nối Backend để tạo yêu cầu thanh toán.', 'error');
    } finally {
      state.loadingCheckout = false;
      if (button) { button.disabled = false; button.textContent = button.dataset.originalText || 'Chọn gói & thanh toán'; }
    }
  }

  function closePaymentCheckout() {
    $('payment-checkout-panel')?.classList.add('hidden');
  }

  async function refreshPaymentHistory() {
    const body = $('payment-history-body');
    if (!body) return;
    if (!userId()) {
      body.innerHTML = '<tr><td colspan="5" class="nf-table-empty">Vui lòng đăng nhập để xem lịch sử.</td></tr>';
      setMessage('payment-history-status', 'Chưa có phiên đăng nhập.', 'warning');
      return;
    }
    setMessage('payment-history-status', 'Đang tải lịch sử giao dịch…', 'info');
    const result = await window.NutriFitAPI.getMyPaymentHistory();
    if (!result.success) {
      body.innerHTML = `<tr><td colspan="5" class="nf-table-empty">${escapeHtml(result.message || 'Không tải được lịch sử.')}</td></tr>`;
      setMessage('payment-history-status', result.message || 'Không tải được lịch sử.', 'error');
      return;
    }
    state.paymentHistory = Array.isArray(result.data) ? result.data : [];
    body.innerHTML = state.paymentHistory.length ? state.paymentHistory.map(txn => `<tr>
      <td>${formatDate(txn.created_at)}</td><td>${escapeHtml(txn.plan_name || '—')}</td><td>${formatMoney(txn.amount)}</td>
      <td><code class="nf-code">${escapeHtml(txn.transaction_code || '—')}</code></td><td>${statusPill(txn.status)}</td>
    </tr>`).join('') : '<tr><td colspan="5" class="nf-table-empty">Bạn chưa có giao dịch nào.</td></tr>';
    setMessage('payment-history-status', `${state.paymentHistory.length} giao dịch. Trạng thái do Backend trả về; làm mới không tự xác nhận khoản tiền đã chuyển.`, 'success');
  }

  function setAdminPeriod(period) {
    state.adminPeriod = period === 'month' ? 'month' : 'day';
    document.querySelectorAll('[data-admin-period]').forEach(button => button.classList.toggle('is-active', button.dataset.adminPeriod === state.adminPeriod));
    loadAdminPage();
  }

  function renderAdminStats(data) {
    const users = data.users || {};
    const financial = data.financial || {};
    const stats = [
      ['Tổng người dùng', Number(users.total) || 0, `${Number(users.free) || 0} tài khoản Free`],
      ['Hội viên Premium', Number(users.premium) || 0, `${Number(users.free) || 0} tài khoản Free`],
      ['Doanh thu thành công', formatMoney(financial.total_revenue_vnd), 'Chỉ tính giao dịch SUCCESS'],
      ['Tổng giao dịch', Number(financial.total_transactions) || 0, 'Bao gồm các trạng thái giao dịch']
    ];
    $('admin-stats').innerHTML = stats.map((item, index) => `<article class="nf-admin-stat nf-admin-stat-${index}"><span>${escapeHtml(item[0])}</span><strong>${escapeHtml(item[1])}</strong><small>${escapeHtml(item[2])}</small></article>`).join('');
  }

  function renderRevenueChart(rows) {
    const target = $('admin-revenue-chart');
    if (!target) return;
    rows = Array.isArray(rows) ? rows : [];
    if (!rows.length) { target.innerHTML = '<p class="nf-table-empty">Chưa có giao dịch thành công trong khoảng dữ liệu này.</p>'; return; }
    const max = Math.max(1, ...rows.map(row => Number(row.revenue) || 0));
    target.innerHTML = `<div class="nf-bar-chart">${rows.slice(-14).map(row => {
      const value = Number(row.revenue) || 0;
      const height = Math.max(4, Math.round(value / max * 100));
      return `<div class="nf-bar-column" title="${escapeHtml(row.timeline)} · ${escapeHtml(formatMoney(value))}"><div class="nf-bar-value">${escapeHtml(formatMoney(value))}</div><div class="nf-bar-track"><div class="nf-bar-fill" style="height:${height}%"></div></div><div class="nf-bar-label">${escapeHtml(row.timeline || '—')}</div></div>`;
    }).join('')}</div>`;
  }

  function renderRecentTransactions(rows) {
    const target = $('admin-recent-transactions');
    if (!target) return;
    if (!rows?.length) { target.innerHTML = '<p class="nf-table-empty">Chưa có giao dịch.</p>'; return; }
    target.innerHTML = rows.map(txn => `<div class="nf-recent-row"><div class="min-w-0"><strong>${escapeHtml(txn.user_name || txn.user_email || `User #${txn.user_id || '—'}`)}</strong><small>${escapeHtml(txn.plan_name || 'Gói dịch vụ')} · ${escapeHtml(formatDate(txn.created_at))}</small><code class="nf-code">${escapeHtml(txn.transaction_code || '')}</code></div><div class="text-right shrink-0"><b>${escapeHtml(formatMoney(txn.amount))}</b><div class="mt-1">${statusPill(txn.status)}</div></div></div>`).join('');
  }

  function renderAdminUsers() {
    const body = $('admin-users-body');
    if (!body) return;
    const needle = ($('admin-user-search')?.value || '').trim().toLowerCase();
    const rows = state.adminUsers.filter(user => [user.email, user.full_name, user.role, user.subscription_status, user.id].some(value => String(value ?? '').toLowerCase().includes(needle)));
    $('admin-users-count').textContent = `${rows.length} / ${state.adminUsers.length} tài khoản`;
    body.innerHTML = rows.length ? rows.map(user => `<tr>
      <td>${escapeHtml(user.id)}</td><td><strong>${escapeHtml(user.full_name || '—')}</strong><small class="nf-cell-sub">${escapeHtml(user.email || '—')}</small></td>
      <td><span class="nf-role-pill ${String(user.role).toUpperCase() === 'ADMIN' ? 'nf-role-admin' : ''}">${escapeHtml(user.role || 'MEMBER')}</span></td>
      <td>${statusPill(user.subscription_status || 'FREE')}</td><td>${formatDate(user.premium_expires_at)}</td><td>${formatDate(user.created_at)}</td>
    </tr>`).join('') : '<tr><td colspan="6" class="nf-table-empty">Không tìm thấy người dùng phù hợp.</td></tr>';
  }

  function renderAdminTransactions() {
    const body = $('admin-transactions-body');
    if (!body) return;
    const needle = ($('admin-transaction-search')?.value || '').trim().toLowerCase();
    const rows = state.adminTransactions.filter(txn => [txn.user_name, txn.user_email, txn.plan_name, txn.transaction_code, txn.payment_method, txn.status].some(value => String(value ?? '').toLowerCase().includes(needle)));
    body.innerHTML = rows.length ? rows.map(txn => `<tr><td>${formatDate(txn.created_at)}</td><td><strong>${escapeHtml(txn.user_name || '—')}</strong><small class="nf-cell-sub">${escapeHtml(txn.user_email || `User #${txn.user_id || '—'}`)}</small></td><td>${escapeHtml(txn.plan_name || '—')}</td><td>${formatMoney(txn.amount)}</td><td>${escapeHtml(txn.payment_method || '—')}</td><td><code class="nf-code">${escapeHtml(txn.transaction_code || '—')}</code></td><td>${statusPill(txn.status)}</td></tr>`).join('') : '<tr><td colspan="7" class="nf-table-empty">Không tìm thấy giao dịch phù hợp.</td></tr>';
  }

  async function loadAdminPage() {
    if (!isAdmin()) {
      applyRoleNavigation();
      setMessage('admin-status', 'Khu vực này chỉ dành cho tài khoản ADMIN.', 'warning');
      return;
    }
    setMessage('admin-status', 'Đang tải số liệu quản trị…', 'info');
    const identity = await syncSessionUser();
    if (!identity || String(identity.role).toUpperCase() !== 'ADMIN') {
      applyRoleNavigation();
      setMessage('admin-status', 'Phiên đăng nhập không có quyền quản trị hoặc đã hết hạn. Hãy đăng nhập lại bằng tài khoản ADMIN.', 'error');
      return;
    }
    const [dashboard, users, transactions] = await Promise.all([
      window.NutriFitAPI.getAdminDashboard(state.adminPeriod),
      window.NutriFitAPI.getAdminUsers(),
      window.NutriFitAPI.getAdminTransactions()
    ]);

    const failures = [dashboard, users, transactions].filter(result => !result.success);
    if (failures.length) {
      setMessage('admin-status', failures.map(result => result.message || `API lỗi ${result.httpStatus || ''}`).join(' · '), 'error');
    } else {
      setMessage('admin-status', 'Dữ liệu đã tải từ Backend. Các bảng quản trị hiện ở chế độ xem/tra cứu.', 'success');
    }

    if (dashboard.success && dashboard.data) {
      renderAdminStats(dashboard.data);
      renderRevenueChart(dashboard.data.revenue_chart);
      renderRecentTransactions(dashboard.data.recent_transactions);
    }
    if (users.success) { state.adminUsers = Array.isArray(users.data) ? users.data : []; renderAdminUsers(); }
    if (transactions.success) { state.adminTransactions = Array.isArray(transactions.data) ? transactions.data : []; renderAdminTransactions(); }
    window.lucide?.createIcons?.();
  }

  function filterAdminUsers() { renderAdminUsers(); }
  function filterAdminTransactions() { renderAdminTransactions(); }

  document.addEventListener('nutrifit:session-updated', applyRoleNavigation);
  document.addEventListener('nutrifit:session-cleared', applyRoleNavigation);
  document.addEventListener('DOMContentLoaded', applyRoleNavigation);

  Object.assign(window, {
    loadPremiumPage,
    startPremiumCheckout,
    closePaymentCheckout,
    refreshPaymentHistory,
    loadAdminPage,
    setAdminPeriod,
    filterAdminUsers,
    filterAdminTransactions
  });
})();
