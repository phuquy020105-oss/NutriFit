# NutriFit — Bản tích hợp để chạy local

Bản này ghép các nguồn đã cung cấp trong cuộc trò chuyện: main (Auth/Admin/Payment/schema cơ sở), TV1 profile-service, TV3 Nutrition V4/Food Catalog/Quick Food, TV4 Workout/Progress/Street Food, Chatbox AI và thư mục Frontend UI mới.

## 1. Thiết lập `.env`

1. Sao chép `.env.example` thành `.env` ở thư mục gốc project.
2. Điền `DB_PASS` theo MySQL local và cấu hình `GEMINI_API_KEY` ở Backend nếu muốn bật AI. `MAIL_*` chỉ cần cấu hình hợp lệ nếu luồng đăng ký của bản base yêu cầu gửi email.
3. Không commit `.env`. ZIP này cố ý không chứa bí mật/cấu hình máy cá nhân.

## 2. Database — đọc kỹ trước khi chạy SQL

- Nếu `NutriFitDB` đã tồn tại, hãy backup trong MySQL Workbench trước, rồi chạy `setup/upgrade_existing_database.sql`. Script này bổ sung các bảng/cột Payment + Nutrition còn thiếu và không xóa dữ liệu hiện tại.
- `setup/create_database.sql` là script khởi tạo schema đầy đủ từ nguồn main; script gốc có lệnh `DROP TABLE` và có thể xóa dữ liệu khi chạy lại. Chỉ dùng cho database mới hoặc sau khi đã chủ động backup và chấp nhận tái tạo.
- Sau khi chạy migration và xác nhận `.env` trỏ đúng `NutriFitDB`, nạp catalog bằng lệnh ở Terminal project root:

  ```cmd
  python setup\seed_nutrition_catalog.py --apply --database NutriFitDB
  ```

  Lệnh này ghi dữ liệu catalog vào database; không chạy nếu chưa backup database quan trọng.

## 3. Cài Python và khởi động

Tại Terminal ở thư mục gốc project:

```cmd
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r backend\requirements.txt
```

Sau đó chạy `run\run_all.bat`. Nó mở Flask Backend ở `http://127.0.0.1:5000`, mở HTTP server Frontend ở cổng `5500`, rồi mở trang `http://127.0.0.1:5500/frontend/index.html`.

Nếu muốn chạy tách riêng:

```cmd
python backend\wsgi.py
```

Trong Terminal thứ hai:

```cmd
python -m http.server 5500
```

Mở `http://127.0.0.1:5500/frontend/index.html`.

## 4. Smoke test

- `http://127.0.0.1:5000/api/health` phải trả JSON `status: connected`.
- Khi database được khởi tạo từ `create_database.sql`, tài khoản mẫu là `user@nutrifit.vn` / `123456` (hoặc `admin@nutrifit.vn` / `123456`). Với DB có sẵn, hãy dùng tài khoản thực tế của bạn. Các API Nutrition sử dụng phiên đăng nhập cookie (Frontend gửi `credentials: include`).
- Chatbox: `POST /api/chatbot/chat`.
- Nutrition: `/api/nutrition/*`, `/api/meals/*`.
- Workout/Progress/Street Food: `/api/workouts/*`, `/api/progress/*`, `/api/street-food/*`.

Các API đã được đăng ký trong app factory. Chức năng vẫn cần database nâng cấp đầy đủ và cấu hình `.env` hợp lệ mới chạy end-to-end. Quick Food phụ thuộc schema catalog/Premium và có thể trả `PREMIUM_REQUIRED` với tài khoản Free.

## 5. Lưu ý bảo mật

- Không đưa `.env`, API key Gemini, mật khẩu MySQL hoặc Gmail App Password vào Git.
- Các gói nguồn có chứa ví dụ cấu hình không an toàn; bản tích hợp này đã thay bằng placeholder. Nếu các khóa thật đã từng được hiển thị trong ảnh/commit, hãy đổi chúng.

## 6. Kiểm thử đã thực hiện khi đóng gói

- Python syntax compilation cho toàn bộ backend/setup Python.
- JavaScript syntax check cho các file frontend (nếu Node.js có sẵn).
- Kiểm tra các CSS/JS được tham chiếu cục bộ trong `frontend/index.html` có tồn tại.
- Chưa thể xác nhận live end-to-end MySQL/Gemini của máy bạn từ bản ZIP này; cần chạy local và thực hiện smoke test ở trên.
