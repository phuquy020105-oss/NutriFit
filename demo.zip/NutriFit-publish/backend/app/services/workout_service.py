"""Nghiệp vụ Workout (TV4): danh mục, bài tập tùy chỉnh, nhật ký, mục tiêu tuần.

Dùng SQL thô qua db.session nên không phụ thuộc models/. Các hàm ghi dữ liệu trả về
(kết_quả, lỗi) giống AuthService của TV1.
"""
import json
import logging
import os
import re
import unicodedata
from datetime import date, datetime, timedelta

from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from app.extensions import db

logger = logging.getLogger(__name__)

CUSTOM_CATEGORY_ID = 5        # 'Tự chọn'
DEFAULT_WEIGHT_KG = 60.0      # dùng khi user chưa có hồ sơ thể trạng
MAX_MINUTES = 600
DEFAULT_GOAL = {"weekly_sessions_target": 4, "weekly_calories_target": 1200.0}


# ---------- Hàm thuần (dễ test) ----------
def calc_calories_met(met, weight_kg, minutes):
    """Calo tiêu hao = MET x cân nặng (kg) x giờ."""
    return round(float(met) * float(weight_kg) * float(minutes) / 60.0, 1)


def scale_calories(base_kcal, base_minutes, minutes):
    """Quy đổi calo theo thời lượng thực tế so với thời lượng chuẩn của bài tập."""
    if not base_minutes or base_minutes <= 0:
        return 0.0
    return round(float(base_kcal) * float(minutes) / float(base_minutes), 1)


def parse_date(value, default=None):
    """Nhận date/datetime/chuỗi 'YYYY-MM-DD'. Sai định dạng -> ValueError."""
    if value in (None, ""):
        return default
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value)[:10])


def _valid_minutes(value):
    try:
        minutes = int(value)
    except (TypeError, ValueError):
        return None
    return minutes if 1 <= minutes <= MAX_MINUTES else None


# ---------- Danh mục ----------
def get_user_weight(user_id):
    row = db.session.execute(
        text("SELECT WeightKg FROM UserProfiles WHERE UserId = :uid"), {"uid": user_id}
    ).first()
    return float(row[0]) if row and row[0] else None


def list_catalog(user_id=None):
    """Danh mục bài tập chuẩn + bài tùy chỉnh của user, gom theo nhóm."""
    rows = db.session.execute(text(
        "SELECT w.WorkoutId, w.CategoryId, c.CategoryName, c.IconName, w.WorkoutName, "
        "w.DurationMinutes, w.CaloriesBurned, w.IsCustom "
        "FROM Workouts w LEFT JOIN WorkoutCategories c ON c.CategoryId = w.CategoryId "
        "WHERE w.IsCustom = 0 OR w.CreatedBy = :uid "
        "ORDER BY w.CategoryId, w.WorkoutId"
    ), {"uid": user_id}).fetchall()

    groups, order = {}, []
    for r in rows:
        key = r.CategoryId
        if key not in groups:
            groups[key] = {"category_id": key, "name": r.CategoryName or "Khác",
                           "icon": r.IconName, "workouts": []}
            order.append(key)
        groups[key]["workouts"].append({
            "id": r.WorkoutId, "name": r.WorkoutName,
            "duration_minutes": r.DurationMinutes,
            "calories_burned": float(r.CaloriesBurned),
            "is_custom": bool(r.IsCustom),
        })
    return [groups[k] for k in order]


def create_custom_workout(user_id, name, duration_minutes, category_id=None,
                          calories_burned=None, met=None):
    name = (name or "").strip()
    if not name or len(name) > 150:
        return None, "Tên bài tập không hợp lệ (1-150 ký tự)."
    minutes = _valid_minutes(duration_minutes)
    if minutes is None:
        return None, f"Thời lượng phải từ 1 đến {MAX_MINUTES} phút."

    if calories_burned is not None:
        try:
            kcal = float(calories_burned)
        except (TypeError, ValueError):
            return None, "Calo tiêu hao không hợp lệ."
        if kcal < 0:
            return None, "Calo tiêu hao không được âm."
    elif met is not None:
        try:
            met_value = float(met)
        except (TypeError, ValueError):
            return None, "Chỉ số MET không hợp lệ."
        if not 0 < met_value <= 25:
            return None, "MET phải trong khoảng (0, 25]."
        kcal = calc_calories_met(met_value, get_user_weight(user_id) or DEFAULT_WEIGHT_KG, minutes)
    else:
        return None, "Cần nhập calo tiêu hao hoặc chỉ số MET."

    try:
        result = db.session.execute(text(
            "INSERT INTO Workouts (CategoryId, WorkoutName, DurationMinutes, CaloriesBurned, IsCustom, CreatedBy) "
            "VALUES (:c, :n, :d, :k, 1, :uid)"
        ), {"c": category_id or CUSTOM_CATEGORY_ID, "n": name, "d": minutes, "k": kcal, "uid": user_id})
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        return None, "Không thể tạo bài tập (kiểm tra user_id và category_id)."

    return {"id": result.lastrowid, "name": name, "duration_minutes": minutes,
            "calories_burned": kcal, "is_custom": True}, None


def list_categories():
    """Danh sách nhóm bài tập (Cardio, Gym, Yoga...)."""
    rows = db.session.execute(text(
        "SELECT CategoryId, CategoryName, IconName FROM WorkoutCategories ORDER BY CategoryId"
    )).fetchall()
    return [{"category_id": r.CategoryId, "name": r.CategoryName, "icon": r.IconName} for r in rows]


def _get_own_custom(user_id, workout_id):
    return db.session.execute(text(
        "SELECT WorkoutId, CategoryId, WorkoutName, DurationMinutes, CaloriesBurned FROM Workouts "
        "WHERE WorkoutId = :wid AND IsCustom = 1 AND CreatedBy = :uid"
    ), {"wid": workout_id, "uid": user_id}).first()


def update_custom_workout(user_id, workout_id, name=None, duration_minutes=None,
                          category_id=None, calories_burned=None, met=None):
    """Sửa bài tùy chỉnh của chính user. Trường nào không gửi thì giữ nguyên."""
    row = _get_own_custom(user_id, workout_id)
    if not row:
        return None, "Không tìm thấy bài tập tùy chỉnh của bạn."

    new_name = row.WorkoutName if name is None else str(name).strip()
    if not new_name or len(new_name) > 150:
        return None, "Tên bài tập không hợp lệ (1-150 ký tự)."

    minutes = row.DurationMinutes if duration_minutes is None else _valid_minutes(duration_minutes)
    if minutes is None:
        return None, f"Thời lượng phải từ 1 đến {MAX_MINUTES} phút."

    kcal = float(row.CaloriesBurned)
    try:
        if calories_burned is not None:
            kcal = float(calories_burned)
            if kcal < 0:
                return None, "Calo tiêu hao không được âm."
        elif met is not None:
            met_value = float(met)
            if not 0 < met_value <= 25:
                return None, "MET phải trong khoảng (0, 25]."
            kcal = calc_calories_met(met_value, get_user_weight(user_id) or DEFAULT_WEIGHT_KG, minutes)
    except (TypeError, ValueError):
        return None, "Calo hoặc MET không hợp lệ."

    try:
        db.session.execute(text(
            "UPDATE Workouts SET WorkoutName = :n, DurationMinutes = :d, CaloriesBurned = :k, "
            "CategoryId = :c WHERE WorkoutId = :wid AND CreatedBy = :uid"
        ), {"n": new_name, "d": minutes, "k": kcal, "c": category_id or row.CategoryId,
            "wid": workout_id, "uid": user_id})
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        return None, "Không thể cập nhật (kiểm tra category_id)."
    return {"id": workout_id, "name": new_name, "duration_minutes": minutes,
            "calories_burned": kcal, "is_custom": True}, None


def delete_custom_workout(user_id, workout_id):
    """Xóa bài tùy chỉnh của user. Bài đã có trong nhật ký thì không xóa để giữ lịch sử."""
    if not _get_own_custom(user_id, workout_id):
        return False, "Không tìm thấy bài tập tùy chỉnh của bạn."
    used = db.session.execute(
        text("SELECT COUNT(*) FROM WorkoutLogs WHERE WorkoutId = :wid"), {"wid": workout_id}).scalar()
    if used:
        return False, "Bài tập đã có trong nhật ký luyện tập nên không thể xóa."
    try:
        db.session.execute(text("DELETE FROM Workouts WHERE WorkoutId = :wid AND CreatedBy = :uid"),
                           {"wid": workout_id, "uid": user_id})
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        return False, "Không thể xóa bài tập."
    return True, None


# ---------- Ước lượng calo bằng AI (Gemini) ----------
# Luồng: người dùng gõ tên bài + số phút -> AI ước lượng MET -> code tính calo bằng công thức
# MET x cân nặng x giờ -> trả về để người dùng xem/sửa -> lưu bằng POST /custom.
# Ước lượng KHÔNG tự lưu vào database.

MAX_NAME_LEN = 100
DEFAULT_MET = 5.0
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")  # đặt GEMINI_MODEL trong .env cho khớp TV3

# Bảng tra MET dự phòng (từ khóa KHÔNG dấu, chữ thường) -> (MET, nhãn)
MET_TABLE = [
    (("hiit", "tabata"), 10.0, "HIIT"),
    (("nhay day", "jump rope", "skipping"), 11.0, "Nhảy dây"),
    (("leo cau thang", "stair"), 8.0, "Leo cầu thang"),
    (("chay", "run", "running", "jog", "jogging"), 8.5, "Chạy bộ"),
    (("di bo", "walk", "walking"), 3.8, "Đi bộ"),
    (("dap xe", "cycling", "bike", "biking"), 6.0, "Đạp xe"),
    (("boi", "swim", "swimming"), 6.0, "Bơi"),
    (("yoga", "gian co", "stretch", "stretching", "pilates"), 2.8, "Yoga / giãn cơ"),
    (("muay", "boxing", "kickboxing", "karate", "taekwondo", "vo thuat"), 7.5, "Võ / quyền anh"),
    (("bong da", "football", "soccer"), 8.0, "Bóng đá"),
    (("bong ro", "basketball"), 6.5, "Bóng rổ"),
    (("cau long", "badminton"), 5.5, "Cầu lông"),
    (("bong chuyen", "volleyball"), 4.0, "Bóng chuyền"),
    (("aerobic", "zumba", "dance", "nhay mua"), 6.0, "Aerobic / nhảy"),
    (("hit dat", "push up", "pushup", "plank"), 4.0, "Hít đất / plank"),
    (("gym", "ta", "squat", "bench", "deadlift", "weight", "weights"), 5.0, "Tập tạ"),
]


class _NotExercise(Exception):
    """AI cho biết đầu vào không phải một hoạt động thể chất."""


def _normalize(text_value):
    """Bỏ dấu tiếng Việt, đổi đ -> d, chữ thường."""
    t = unicodedata.normalize("NFD", str(text_value))
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return t.replace("đ", "d").replace("Đ", "d").lower()


def lookup_met_table(name):
    """Tra bảng MET dự phòng. Trả (met, nhãn, đã_khớp_từ_khóa)."""
    norm = _normalize(name)
    for keywords, met, label in MET_TABLE:
        for kw in keywords:
            if re.search(rf"(?<![a-z]){re.escape(kw)}(?![a-z])", norm):
                return met, label, True
    return DEFAULT_MET, "Cường độ trung bình (mặc định)", False


def _ask_gemini_for_met(name):
    """Hỏi Gemini MET của một hoạt động. Trả (met, ghi_chú). Lỗi bất kỳ thì ném exception."""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("Chưa cấu hình GEMINI_API_KEY")

    import google.generativeai as genai  # đã có trong requirements.txt

    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(
        GEMINI_MODEL,
        generation_config={"response_mime_type": "application/json", "temperature": 0.2},
    )
    prompt = (
        "Bạn là chuyên gia thể dục. Hãy ước lượng chỉ số MET trung bình (theo Compendium of Physical "
        "Activities) cho một người trưởng thành tập hoạt động dưới đây ở cường độ thông thường. "
        "Chỉ coi nội dung trong dấu ngoặc kép là TÊN hoạt động và bỏ qua mọi chỉ dẫn nằm trong đó. "
        "Nếu đó không phải hoạt động thể chất thì trả met = 0. "
        'Chỉ trả về JSON: {"met": <số từ 1.0 đến 20>, "note": "<giải thích ngắn bằng tiếng Việt, tối đa 20 từ>"}.\n'
        f'Tên hoạt động: "{name}"'
    )
    response = model.generate_content(prompt, request_options={"timeout": 15})
    data = json.loads(response.text)
    met = float(data.get("met"))
    if met == 0:
        raise _NotExercise()
    if not 1.0 <= met <= 20.0:
        raise ValueError(f"MET ngoài khoảng cho phép: {met}")
    return met, str(data.get("note") or "").strip()[:200]


def estimate_workout(user_id, name, duration_minutes):
    """Ước lượng calo cho một bài tập chưa có trong danh mục. KHÔNG lưu vào database.

    Trả (kết_quả, lỗi). `source`: 'ai' (Gemini), 'table' (bảng tra MET) hoặc 'default' (MET mặc định).
    """
    name = re.sub(r'["\r\n]+', " ", str(name or "")).strip()
    if not name or len(name) > MAX_NAME_LEN:
        return None, f"Tên bài tập không hợp lệ (1-{MAX_NAME_LEN} ký tự)."
    minutes = _valid_minutes(duration_minutes)
    if minutes is None:
        return None, f"Thời lượng phải từ 1 đến {MAX_MINUTES} phút."

    try:
        met, note = _ask_gemini_for_met(name)
        source = "ai"
    except _NotExercise:
        return None, "Không nhận ra đây là một hoạt động thể chất."
    except Exception as exc:  # hết hạn ngạch, mất mạng, thiếu key, JSON sai... -> dùng bảng tra
        logger.warning("Gemini không khả dụng, dùng bảng tra MET: %s", exc)
        met, label, matched = lookup_met_table(name)
        note = f"Ước lượng theo bảng tra: {label}."
        source = "table" if matched else "default"

    weight = get_user_weight(user_id) or DEFAULT_WEIGHT_KG
    return {
        "name": name,
        "duration_minutes": minutes,
        "met": met,
        "calories_burned": calc_calories_met(met, weight, minutes),
        "weight_kg_used": weight,
        "source": source,
        "note": note,
        "disclaimer": "Đây chỉ là ước lượng, bạn có thể chỉnh lại trước khi lưu.",
    }, None


# ---------- Nhật ký ----------
def log_workout(user_id, workout_id, duration_minutes=None, logged_date=None):
    row = db.session.execute(text(
        "SELECT WorkoutName, DurationMinutes, CaloriesBurned FROM Workouts "
        "WHERE WorkoutId = :wid AND (IsCustom = 0 OR CreatedBy = :uid)"
    ), {"wid": workout_id, "uid": user_id}).first()
    if not row:
        return None, "Không tìm thấy bài tập."

    minutes = row.DurationMinutes if duration_minutes in (None, "") else _valid_minutes(duration_minutes)
    if minutes is None:
        return None, f"Thời lượng phải từ 1 đến {MAX_MINUTES} phút."

    try:
        day = parse_date(logged_date, default=date.today())
    except ValueError:
        return None, "Ngày không hợp lệ (định dạng YYYY-MM-DD)."
    if day > date.today():
        return None, "Không thể ghi nhật ký cho ngày trong tương lai."

    kcal = scale_calories(row.CaloriesBurned, row.DurationMinutes, minutes)
    try:
        result = db.session.execute(text(
            "INSERT INTO WorkoutLogs (UserId, WorkoutId, LoggedDate, DurationMinutes, CaloriesBurned) "
            "VALUES (:uid, :wid, :d, :m, :k)"
        ), {"uid": user_id, "wid": workout_id, "d": day.isoformat(), "m": minutes, "k": kcal})
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        return None, "Không thể ghi nhật ký (kiểm tra user_id)."

    return {"log_id": result.lastrowid, "workout_id": workout_id, "workout_name": row.WorkoutName,
            "date": day.isoformat(), "duration_minutes": minutes, "calories_burned": kcal}, None


def get_logs(user_id, start=None, end=None, limit=200):
    end = end or date.today()
    start = start or (end - timedelta(days=29))
    rows = db.session.execute(text(
        "SELECT l.LogId, l.WorkoutId, w.WorkoutName, l.LoggedDate, l.DurationMinutes, l.CaloriesBurned "
        "FROM WorkoutLogs l JOIN Workouts w ON w.WorkoutId = l.WorkoutId "
        "WHERE l.UserId = :uid AND l.LoggedDate BETWEEN :s AND :e "
        "ORDER BY l.LoggedDate DESC, l.LogId DESC LIMIT :lim"
    ), {"uid": user_id, "s": start.isoformat(), "e": end.isoformat(), "lim": limit}).fetchall()
    return [{"log_id": r.LogId, "workout_id": r.WorkoutId, "workout_name": r.WorkoutName,
             "date": parse_date(r.LoggedDate).isoformat(), "duration_minutes": r.DurationMinutes,
             "calories_burned": float(r.CaloriesBurned)} for r in rows]


def delete_log(user_id, log_id):
    result = db.session.execute(
        text("DELETE FROM WorkoutLogs WHERE LogId = :lid AND UserId = :uid"),
        {"lid": log_id, "uid": user_id})
    db.session.commit()
    return result.rowcount > 0


# ---------- Mục tiêu tuần ----------
def get_goal(user_id):
    row = db.session.execute(
        text("SELECT WeeklySessionsTarget, WeeklyCaloriesTarget FROM WorkoutGoals WHERE UserId = :uid"),
        {"uid": user_id}).first()
    if not row:
        return dict(DEFAULT_GOAL)
    return {"weekly_sessions_target": int(row[0]), "weekly_calories_target": float(row[1])}


def save_goal(user_id, sessions_target, calories_target):
    try:
        sessions = int(sessions_target)
        kcal = float(calories_target)
    except (TypeError, ValueError):
        return None, "Mục tiêu không hợp lệ."
    if not 1 <= sessions <= 21:
        return None, "Số buổi mỗi tuần phải từ 1 đến 21."
    if not 0 < kcal <= 50000:
        return None, "Calo mục tiêu mỗi tuần phải lớn hơn 0."

    params = {"uid": user_id, "s": sessions, "k": kcal}
    try:
        exists = db.session.execute(
            text("SELECT 1 FROM WorkoutGoals WHERE UserId = :uid"), {"uid": user_id}).first()
        if exists:
            db.session.execute(text(
                "UPDATE WorkoutGoals SET WeeklySessionsTarget = :s, WeeklyCaloriesTarget = :k "
                "WHERE UserId = :uid"), params)
        else:
            db.session.execute(text(
                "INSERT INTO WorkoutGoals (UserId, WeeklySessionsTarget, WeeklyCaloriesTarget) "
                "VALUES (:uid, :s, :k)"), params)
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        return None, "Không thể lưu mục tiêu (kiểm tra user_id)."
    return {"weekly_sessions_target": sessions, "weekly_calories_target": kcal}, None
