from flask import Blueprint, request, jsonify, session
from app.services.auth_service import AuthService
from app.models.user import User

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    email = data.get('email')
    password = data.get('password')
    full_name = data.get('full_name')

    if not email or not password or not full_name:
        return jsonify({"success": False, "message": "Vui lòng nhập đầy đủ thông tin!"}), 400

    user, error = AuthService.register(email, password, full_name)
    if error:
        return jsonify({"success": False, "message": error}), 400

    session.clear()
    session["nutrifit_user_id"] = int(user["id"])
    return jsonify({
        "success": True,
        "message": "Đăng ký thành công!",
        "user": user
    }), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        return jsonify({"success": False, "message": "Vui lòng nhập email và mật khẩu!"}), 400

    user, error = AuthService.login(email, password)
    if error:
        return jsonify({"success": False, "message": error}), 401

    session.clear()
    session["nutrifit_user_id"] = int(user["id"])
    return jsonify({
        "success": True,
        "message": "Đăng nhập thành công!",
        "user": user
    }), 200


@auth_bp.route('/me', methods=['GET'])
def current_user():
    """Return the user belonging to the signed Flask session cookie."""
    user_id = session.get("nutrifit_user_id")
    if type(user_id) is not int:
        session.clear()
        return jsonify({"success": False, "message": "Phiên đăng nhập đã hết hạn."}), 401
    user = User.query.get(user_id)
    if user is None:
        session.clear()
        return jsonify({"success": False, "message": "Tài khoản không còn tồn tại."}), 401
    return jsonify({"success": True, "user": user.to_dict()}), 200