from flask import Blueprint, request, jsonify
from app.services.profile_service import ProfileService
from app.models.health import UserProfile
from app.module_auth import login_required, check_user_identity
from app.services.module_errors import api_errors

# Keep existing Frontend route contract (/save and /<user_id>) for compatibility.
profile_bp = Blueprint('profile_bp', __name__)


@profile_bp.route('/save', methods=['POST'])
@api_errors
@login_required
def save_profile():
    data = request.get_json(silent=True) or {}
    user_id = check_user_identity(data)

    profile, error = ProfileService.save_profile(user_id, data)
    if error:
        return jsonify({"success": False, "message": error}), 400
    if profile is None:
        return jsonify({"success": False, "message": "Không thể lưu hồ sơ."}), 500

    return jsonify({
        "success": True,
        "message": "Lưu hồ sơ thành công!",
        "data": {
            "bmr": profile.Bmr,
            "tdee": profile.Tdee,
            "target_kcal": profile.TargetKcal,
            "target_water_ml": profile.TargetWaterMl,
        },
    }), 200


@profile_bp.route('/<int:user_id>', methods=['GET'])
@api_errors
@login_required
def get_profile(user_id):
    user_id = check_user_identity(path_user_id=user_id)
    profile = UserProfile.query.filter_by(UserId=user_id).first()
    if not profile:
        return jsonify({"success": False, "message": "Chưa có dữ liệu hồ sơ"}), 404

    return jsonify({
        "success": True,
        "data": {
            "gender": profile.Gender,
            "age": profile.Age,
            "height": profile.HeightCm,
            "weight": profile.WeightKg,
            "goal": profile.Goal,
            "bmr": profile.Bmr,
            "tdee": profile.Tdee,
            "target_kcal": profile.TargetKcal,
            "target_water_ml": profile.TargetWaterMl,
        },
    }), 200
