from functools import wraps
from flask import jsonify, session
from app.models.user import User


def admin_required(f):
    """Protect admin APIs with the signed server-side session, not a spoofable ID header."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = session.get("nutrifit_user_id")
        if type(user_id) is not int:
            return jsonify({"success": False, "message": "Vui lòng đăng nhập để thực hiện chức năng này."}), 401

        user = User.query.get(user_id)
        if user is None:
            session.clear()
            return jsonify({"success": False, "message": "Phiên đăng nhập không còn hợp lệ."}), 401
        if str(user.Role or "MEMBER").upper() != "ADMIN":
            return jsonify({"success": False, "message": "Truy cập bị từ chối. Chức năng này yêu cầu quyền ADMIN."}), 403
        return f(*args, **kwargs)
    return decorated_function
