"""NutriFit application factory integrating core, nutrition, workout and chatbot APIs."""
import os
from flask import Flask, jsonify
from app.config import Config
from app.extensions import db, cors, mail


def _frontend_origins():
    raw = os.getenv(
        "NUTRITION_FRONTEND_ORIGINS",
        "http://127.0.0.1:5500,http://localhost:5500,http://127.0.0.1:8000,http://localhost:8000",
    )
    return [origin.strip() for origin in raw.split(",") if origin.strip()]


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # These extensions are initialized once on the combined app.
    db.init_app(app)
    cors.init_app(
        app,
        resources={r"/api/*": {"origins": _frontend_origins()}},
        supports_credentials=True,
    )
    mail.init_app(app)

    # Base project: authentication, profile, admin and payment.
    from app.routes.auth import auth_bp
    from app.routes.profile import profile_bp
    from app.routes.admin import admin_bp
    from app.routes.payment import payment_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(profile_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(payment_bp)

    # TV4: Workout, weekly Progress and Street Food.
    from app.routes.workouts import workout_bp, progress_bp, street_food_bp
    app.register_blueprint(workout_bp, url_prefix="/api/workouts")
    app.register_blueprint(progress_bp, url_prefix="/api/progress")
    app.register_blueprint(street_food_bp, url_prefix="/api/street-food")

    # Chatbox AI.
    from app.routes.chatbot import chatbot_bp
    app.register_blueprint(chatbot_bp)

    # TV3: Nutrition V4, meal planner, food intake/catalog and Premium Quick Food.
    from app.nutrition_module import init_nutrition
    init_nutrition(app)

    @app.route("/api/health", methods=["GET"])
    def health_check():
        return jsonify({
            "status": "connected",
            "message": "NutriFit Backend: core, nutrition, workout and chatbot modules loaded",
        }), 200

    return app
